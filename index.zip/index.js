const express = require('express');
const cors = require('cors');
const mysql = require('mysql');

const app = express();
app.use(cors());
app.use(express.json());


const port = process.env.PORT || 8080;


const db = mysql.createConnection({
   host: 'localhost',
  user: 'shadigho_lr',
  password: 'NcPCpUT6AiL4Kq8',
  database: 'shadigho_lr',
})



app.get('/', (req, res) => {

  const  sql = "SELECT * FROM user_tast";
    
    db.query(sql, (err, rows, fields) => {
        if (err) throw err
      
        console.log('The solution is: ', rows[0].solution)
        res.json(rows)
      })
      



  });
  


app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
  });
  